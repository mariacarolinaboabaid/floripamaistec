﻿using System;
namespace Escola.Controllers
{
	public class AlunoController
	{
		public AlunoController()
		{
		}
	}
}

